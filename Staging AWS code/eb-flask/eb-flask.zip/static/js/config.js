// API key
const API_KEY = "pk.eyJ1IjoiaXJlbmVzaHRlcGEiLCJhIjoiY2s1eDN6dzFvMjI0ZjNlbnF0cnE0cWt4aiJ9._hUFiwO3r7xzw9Te7fvfkQ";
