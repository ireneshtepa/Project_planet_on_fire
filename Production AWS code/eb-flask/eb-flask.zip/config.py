#Twitter standard search API

consumer_key = "iFU0UAXonvu3Mj96SnFX4SWz9"

consumer_secret = "cQWhnX7y8b8TnjiRbZ9KPpFlrrw18ZGkjQeICPHRFoUkiiyn7Q"

access_token = "3245361546-e1NtWlJUAoodH9lIs59oV4wooPy6vhZXYq3LcO8"

access_token_secret = "6LtrCsiK4gRpE9TVUhnNumHwMI83THcY7Djn5jBEYhgXV"