// condition for dropdown menue
var continents = [
  {"Name": "Africa", "Location": [7.026601, 17.517169], "Zoom": 5},
  {"Name": "Asia", "Location": [24.704768, 92.144528], "Zoom": 5},
  {"Name": "Australia", "Location": [-25.985928, 133.881768], "Zoom": 5},
  {"Name": "Europe", "Location": [46.860477, 17.705424], "Zoom": 5},
  {"Name": "North America", "Location": [33.584754, -91.103957], "Zoom": 5},
  {"Name": "South America", "Location": [3.376254, -61.164163], "Zoom": 5}
];



